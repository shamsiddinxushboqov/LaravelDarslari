<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/dataTables.min.css')); ?>"> -->
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Bu foydalanuvchining shaxsiy kabineti</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <h4>Bu yerda siz firmamizda bor avto extiyot qismlar bilan tanishishingiz mumkin</h4>


                     <div class="card-body">
        <div class="table-responsive">
            <input id="myInput" type="text" placeholder="Search..">
<br><br>

          <table id="datable" class="table">
            <thead class=" text-primary">
              <!-- <th>Id_mahsulot</th> -->
              <th>Nomi</th>
              <th>Narxi</th>
            
            </thead>
            <tbody id="myTable">
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <!-- <td><?php echo e($data->id_mahsulot); ?></td> -->
                <td><?php echo e($data->Nomi); ?></td>
                <td><?php echo e($data->Narxi); ?></td>
              <td>
                  <div style="height: 80px;overflow: hidden;">
                    <?php echo e($data->description); ?>

                  </div>
                </td>
             </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           </tbody>
         </table>
         <?php echo e($products->links()); ?>

       </div>
     </div>
                </div>
            </div>





        </div>
    </div>
</div>
<!-- <script src="<?php echo e(asset('assets/js/dataTables.min.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

  // $(document).ready( function () {
  //   $('#datable').DataTable();
  // } );  

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adminPanel1\resources\views/home.blade.php ENDPATH**/ ?>