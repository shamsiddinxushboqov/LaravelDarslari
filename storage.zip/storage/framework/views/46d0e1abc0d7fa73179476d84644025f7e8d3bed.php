<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Angor Avto Servis MChJ</title>
   
    <!-- Datatables -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/dataTables.min.css')); ?>">
<!-- endDatatables -->

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
</head>
<style>
.fixed-top{
  /*position: absolute;*/
}  
</style>
<body>
     

<div id="app">


        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
  <!-- Template Main JS File -->
  <script src="assets/assets/js/main.js"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\adminPanel1\resources\views/layouts/homeapp.blade.php ENDPATH**/ ?>