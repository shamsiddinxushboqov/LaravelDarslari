<?php $__env->startSection('title'); ?>
	Biz haqimizda malumotlarini taxrirlash
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
		<div class="row">
          	<div class="col-md-12">
            	<div class="card">
              		<div class="card-header">
                		<h4 class="card-title"> Biz haqimizda malumotlarini o'zgartirish</h4>
							<form action="<?php echo e(url('abouts-update/'.$abouts->id)); ?>" method="POST">
								<!-- Mana shu yeri xato beryapti -->
							    <?php echo e(csrf_field()); ?>

							    <?php echo e(method_field('PUT')); ?>

							    <div class="modal-body">
							        <div class="form-group">
							        	<label for="recipient-name" class="col-form-label">Title:</label>
							            <input type="text" name="title" class="form-control" value="<?php echo e($abouts->title); ?>">
							         </div>
							         <div class="form-group">
							            <label for="recipient-name" class="col-form-label">Sub-Title:</label>
							            <input type="text" name="subtitle" class="form-control" value="<?php echo e($abouts->subtitle); ?>">
							          </div>
							          <div class="form-group">
							            <label for="message-text" class="col-form-label">Description:</label>
							            <textarea name="description"  class="form-control" value="<?php echo e($abouts->description); ?>" rows="6"></textarea>
							          </div>
							    </div>

							    <div class="modal-footer">
							        <a href="<?php echo e(url('abouts')); ?>" class="btn btn-secondary" >Yopish</a>
							        <button type="submit" class="btn btn-primary">Saqlash</button>
							      </div>

							</form>



            		</div>
        		</div>
    		</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adminPanel1\resources\views/admin/abouts/edit.blade.php ENDPATH**/ ?>