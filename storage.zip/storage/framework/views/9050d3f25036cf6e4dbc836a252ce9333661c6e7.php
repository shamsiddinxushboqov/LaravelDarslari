<?php $__env->startSection('title'); ?>
	Xodimlar malumotlarini taxrirlash
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
		<div class="row">
          	<div class="col-md-12">
            	<div class="card">
              		<div class="card-header">
                		<h4 class="card-title"> Xodimlar malumotlarini o'zgartirish</h4>
							<form action="<?php echo e(url('xodimlar-update/'.$xodimlar->id)); ?>" method="POST">
								<!-- Mana shu yeri xato beryapti -->
							    <?php echo e(csrf_field()); ?>

							    <?php echo e(method_field('PUT')); ?>

							    <div class="modal-body">
							          <div class="form-group">
							            <label for="recipient-name" class="col-form-label">Familyasi:</label>
							            <input type="text" name="Familyasi" class="form-control" id="recipient-name"  value="<?php echo e($xodimlar->Familyasi); ?>">
							          </div>
							          <div class="form-group">
							            <label for="recipient-name" class="col-form-label">Ismi:</label>
							            <input type="text" name="Ismi" class="form-control" id="recipient-name"  value="<?php echo e($xodimlar->Ismi); ?>">
							          </div>
							          <div class="form-group">
							            <label for="recipient-name" class="col-form-label">Otasining ismi:</label>
							            <input type="text" name="Otasining_ismi"  class="form-control" id="recipient-name" value="<?php echo e($xodimlar->Otasining_ismi); ?>"></input>
							          </div>
							          <div class="form-group">
							            <label for="recipient-name" class="col-form-label">Lavozimi:</label>
							            <input type="text" name="Lavozimi"  class="form-control" id="recipient-name"  value="<?php echo e($xodimlar->Lavozimi); ?>"></input>
							          </div>
							          <div class="form-group">
							            <label for="recipient-name" class="col-form-label">Yoshi:</label>
							            <input type="text" name="Yoshi"  class="form-control" id="recipient-name"  value="<?php echo e($xodimlar->Yoshi); ?>"></input>
							          </div>
							          <div class="form-group">
							            <label for="recipient-name" class="col-form-label">Maoshi:</label>
							            <input type="text" name="Maoshi"  class="form-control" id="recipient-name"  value="<?php echo e($xodimlar->Maoshi); ?>"></input>
							          </div>
       							</div>

							    <div class="modal-footer">
							        <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-secondary" >Yopish</a>
							        <button type="submit" class="btn btn-primary">Saqlash</button>
							     </div>

							</form>
            		</div>
        		</div>
    		</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adminPanel1\resources\views/admin/xodimlar/xodimlar-edit.blade.php ENDPATH**/ ?>