<?php $__env->startSection('title'); ?>
	Dashboard admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Xodim qo'shish</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        
      </div>

      <form action="/save-person" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Familyasi:</label>
            <input type="text" name="Familyasi" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Ismi:</label>
            <input type="text" name="Ismi" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Otasining ismi:</label>
            <input type="text" name="Otasining_ismi"  class="form-control" id="recipient-name"></input>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Lavozimi:</label>
            <input type="text" name="Lavozimi"  class="form-control" id="recipient-name"></input>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Yoshi:</label>
            <input type="text" name="Yoshi"  class="form-control" id="recipient-name"></input>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Maoshi:</label>
            <input type="text" name="Maoshi"  class="form-control" id="recipient-name"></input>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Yopish</button>
          <button type="submit" class="btn btn-primary">Saqlash</button>
        </div>

      </form>
    </div>
  </div>
</div>


<!-- Deletes modal -->
<!-- Xodimni ochirish -->
<div class="modal fade" id="deletemodalpop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" style="color: red">Ogoxlantirish!!!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <form id="delete_modal" method="POST">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>


        <div class="modal-body">
          <input type="hidden" id="delete_abouts_id">
          <h5>Siz bu malumotni haqiqatdan ham o'chirmoqchimisiz</h5>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Yopish</button>
          <button type="submit" class="btn btn-primary">Xa, O'chirilsin</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- end delete model -->




	<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"> Xodimlar ro'yxati
      <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">Qo'shish</button>
        </h4>
         
        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
          <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table" id="datable">
            <thead class=" text-primary">
              <th>Id_xodim</th>
              <th>Familyasi</th>
              <th>Ismi</th>
              <th>Otasining_ismi</th>
              <th>Lavozimi</th>
              <th>Yoshi</th>
              <th>Maoshi</th>
              <th class="w-10p">Tahrirlash</th>
              <th class="w-10p">O'chirish</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $xodimlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->Familyasi); ?></td>
                <td><?php echo e($item->Ismi); ?></td>
                <td><?php echo e($item->Otasining_ismi); ?></td>
                <td><?php echo e($item->Lavozimi); ?></td>
                <td><?php echo e($item->Yoshi); ?></td>
                <td><?php echo e($item->Maoshi); ?></td>
                <td>
                  <a href="<?php echo e(url('person-us/'.$item->id)); ?>" class="btn btn-success">Tahrirlash</a>
                </td>
                <td>
                 <a href="javascript:void(0)" class="btn btn-danger deletebtn" >O`chirish</a>
               </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready( function () {
    $('#datable').DataTable();

    $('#datable').on('click','.deletebtn',function(){
      $tr=$(this).closest('tr');
      var data=$tr.children("td").map(function(){
        return $(this).text();
      }).get();
      $('#delete_abouts_id').val(data[0]);
      $('#delete_modal').attr('action','/xodimlar-delete/'+data[0]);
      $('#deletemodalpop').modal('show');
    });
  } );  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adminPanel1\resources\views/admin/xodimlar.blade.php ENDPATH**/ ?>