<?php $__env->startSection('title'); ?>
Tovarlar ro'yxati
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tovar qo'shish</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        
      </div>

      <form action="/save-products" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Id_mahsulot:</label>
            <input type="text" name="id_mahsulot" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nomi:</label>
            <input type="text" name="Nomi" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Narxi:</label>
            <input type="text" name="Narxi"  class="form-control" id="recipient-name"></input>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Soni:</label>
            <input type="text" name="Soni"  class="form-control" id="recipient-name"></input>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Yopish</button>
          <button type="submit" class="btn btn-primary">Saqlash</button>
        </div>

      </form>
    </div>
  </div>
</div>










<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"> Tovarlar ro'yxati
<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">Qo'shish</button>
        </h4>
         
        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
          <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table" id="datable">
            <thead class=" text-primary">
              <th>Id</th>
              <th>Id_mahsulot</th>
              <th>Nomi</th>
              <th>Narxi</th>
              <th>Soni</th>
              <th class="w-10p">Tahrirlash</th>
              <th class="w-10p">O'chirish</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->id_mahsulot); ?></td>
                <td><?php echo e($item->Nomi); ?></td>
                <td><?php echo e($item->Narxi); ?></td>
                <td><?php echo e($item->Soni); ?></td>
                <td>
                  <a href="#" class="btn btn-success">Tahrirlash</a>
                </td>
                <td>
                 <a href="#" class="btn btn-danger deletebtn" >O`chirish</a>
               </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready( function () {
    $('#datable').DataTable();

    $('#datable').on('click','.deletebtn',function(){
      $tr=$(this).closest('tr');
      var data=$tr.children("td").map(function(){
        return $(this).text();
      }).get();
      $('#delete_abouts_id').val(data[0]);
      $('#delete_modal').attr('action','/about-us-delete/'+data[0]);
      $('#deletemodalpop').modal('show');
    });
  } );  
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adminPanel1\resources\views/admin/products.blade.php ENDPATH**/ ?>