<?php $__env->startSection('title'); ?>
Registratsiyadan o'tgan Foydalanuvchilar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"> Registratsiyadan o'tgan Foydalanuvchilar</h4>
        <h4 class="card-title" style="color: blue"> Muhammad al-Xorazmiy nomidagi TATU KIF AT-servis 217-17 guruh talabalari elektron ruyxati</h4>
        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
          <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table" id="datable">
            <thead class=" text-primary">
              <th>Id nomeri</th>
              <th>Nomi</th>
              <th>Narxi</th>
              <th>Soni</th>
              <th>Edit</th>
              <th>Delete</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->Nomi); ?></td>
                <td><?php echo e($row->Narxi); ?></td>
                <td><?php echo e($row->Soni); ?></td>
                <td>
                  <a href="/role-edit/<?php echo e($row->id); ?>" class="btn btn-success">Edit</a>
                </td>
                <td>
                  <form action="/role-delete/<?php echo e($row->id); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                    <button type="submit" class="btn btn-danger">Delete</button>
                  </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <!-- + -->
          <?php echo e($users->links()); ?>

        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready( function () {
    $('#datable').DataTable();
  } );  
</script>	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adminPanel1\resources\views/admin/product/products.blade.php ENDPATH**/ ?>